# tcp-asyncio-client

[![PyPI - Version](https://img.shields.io/pypi/v/tcp-asyncio-client.svg)](https://pypi.org/project/tcp-asyncio-client)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tcp-asyncio-client.svg)](https://pypi.org/project/tcp-asyncio-client)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install tcp-asyncio-client
```

## License

`tcp-asyncio-client` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
